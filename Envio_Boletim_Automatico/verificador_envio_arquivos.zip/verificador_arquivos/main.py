import os
import glob
import datetime
import pandas as pd
from win32com.client import Dispatch

# === CONFIGURAÇÕES ===
diretorio = r"\\caminho\da\pasta\compartilhada"  # Altere para seu caminho real
padroes_arquivos = {
    "ICATU": "ARQEMISS_ICATU_*.txt",
    "TOKIO MARINE": "ARQEMISS_TOKIO_*.txt"
}

# === LISTA DE DATAS ÚTEIS DO MÊS ATÉ HOJE ===
hoje = datetime.date.today()
primeiro_dia = hoje.replace(day=1)
datas_uteis = pd.bdate_range(start=primeiro_dia, end=hoje).date

# === VERIFICAÇÃO POR SEGURADORA E DIA ===
dados = {}

for seguradora, padrao in padroes_arquivos.items():
    arquivos = glob.glob(os.path.join(diretorio, padrao))
    status_por_dia = []

    for dia in datas_uteis:
        enviado = any(datetime.date.fromtimestamp(os.path.getmtime(arq)) == dia for arq in arquivos)
        status_por_dia.append("✅" if enviado else "❌")
    
    dados[seguradora] = status_por_dia

# === CONSTRUIR DATAFRAME COM DATAS COMO COLUNAS ===
colunas = [data.strftime('%d/%m') for data in datas_uteis]
df_dash = pd.DataFrame(dados, index=colunas).T
df_dash.index.name = "Seguradora"

# === GERAR HTML PARA O E-MAIL ===
html_table = df_dash.to_html(escape=False)

# === CRIAR RASCUNHO DE EMAIL NO OUTLOOK ===
outlook = Dispatch("Outlook.Application")
mail = outlook.CreateItem(0)

mail.Subject = f"[Relatório] Envio de Arquivos - {hoje.strftime('%B/%Y')}"
mail.HTMLBody = f"""
<p>Olá,</p>
<p>Segue abaixo o status acumulado de envio dos arquivos das seguradoras referente ao mês de <b>{hoje.strftime('%B/%Y')}</b>:</p>
{html_table}
<p>Atenciosamente,<br>Equipe de Automação</p>
"""

mail.Display()
